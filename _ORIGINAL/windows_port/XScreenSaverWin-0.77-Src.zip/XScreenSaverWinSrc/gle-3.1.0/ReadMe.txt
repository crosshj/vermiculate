This folder contains the GLE library that the Extrusion screen saver needs.
Binary are compiled by VC++; using the run-time libraries "Debug Multithreaded" 
and "Multithreaded" (non-DLL).

Copy the include and lib folders to the compiling environment before compiling 
Extrusion.

-------------------------------------------------------------------------------

http://www.linas.org/gle/
