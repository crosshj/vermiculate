#define DEF_TEXT \
"Episode IV\\n" \
"\\n" \
"STAR WARS: A NEW HOPE\\n" \
"\\n" \
"It is a period of Civil War.\\n" \
"Rebel Spaceships, striking\\n" \
"from a hidden base, have won\\n" \
"their first victory against\\n" \
"the evil Galactic Empire.\\n" \
"\\n" \
"During the battle, Rebel\\n" \
"spies managed to steal secret\\n" \
"plans to the Empire's\\n" \
"ultimate weapon, the DEATH\\n" \
"STAR, an armored space\\n" \
"station with enough power to\\n" \
"destroy an entire planet.\\n" \
"\\n" \
"Pursued by the Empire's\\n" \
"sinister agents, Princess\\n" \
"Leia races home aboard her\\n" \
"starship, custodian of the\\n" \
"stolen plans that can save\\n" \
"her people and restore\\n" \
"freedom to the galaxy...\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"Episode V\\n" \
"\\n" \
"THE EMPIRE STRIKES BACK\\n" \
"\\n" \
"It is a dark time for the\\n" \
"Rebellion. Although the Death\\n" \
"Star has been destroyed,\\n" \
"Imperial troops have driven the\\n" \
"Rebel forces from their hidden\\n" \
"base and pursued them across\\n" \
"the galaxy.\\n" \
"\\n" \
"Evading the dreaded Imperial\\n" \
"Starfleet, a group of freedom\\n" \
"fighters led by Luke Skywalker\\n" \
"has established a new secret\\n" \
"base on the remote ice world\\n" \
"of Hoth.\\n" \
"\\n" \
"The evil lord Darth Vader,\\n" \
"obsessed with finding young\\n" \
"Skywalker, has dispatched\\n" \
"thousands of remote probes into\\n" \
"the far reaches of space....\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"Episode VI\\n" \
"\\n" \
"RETURN OF THE JEDI\\n" \
"\\n" \
"Luke Skywalker has returned to\\n" \
"his home planet of Tatooine in\\n" \
"an attempt to rescue his\\n" \
"friend Han Solo from the\\n" \
"clutches of the vile gangster\\n" \
"Jabba the Hutt.\\n" \
"\\n" \
"Little does Luke know that the\\n" \
"GALACTIC EMPIRE has secretly\\n" \
"begun construction on a new\\n" \
"armored space station even\\n" \
"more powerful than the first\\n" \
"dreaded Death Star.\\n" \
"\\n" \
"When completed, this ultimate\\n" \
"weapon will spell certain doom\\n" \
"for the small band of rebels\\n" \
"struggling to restore freedom\\n" \
"to the galaxy...\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"Episode I\\n" \
"\\n" \
"THE PHANTOM MENACE\\n" \
"\\n" \
"Turmoil has engulfed the\\n" \
"Galactic Republic.  The taxation\\n" \
"of trade routes to outlying star\\n" \
"systems is in dispute.\\n" \
"\\n" \
"Hoping to resolve the matter\\n" \
"with a blockade of deadly\\n" \
"battleships, the greedy Trade\\n" \
"Federation has stopped all\\n" \
"shipping to the small planet\\n" \
"of Naboo.\\n" \
"\\n" \
"While the Congress of the\\n" \
"Republic endlessly debates\\n" \
"this alarming chain of events,\\n" \
"the Supreme Chancellor has\\n" \
"secretly dispatched two Jedi\\n" \
"Knights, the guardians of\\n" \
"peace and justice in the\\n" \
"galaxy to settle the conflict...\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"Episode II\\n" \
"\\n" \
"ATTACK OF THE CLONES\\n" \
"\\n" \
"There is unrest in the Galactic\\n" \
"Senate.  Several thousand solar\\n" \
"systems have declared their\\n" \
"intentions to leave the Republic.\\n" \
"\\n" \
"This separatist movement,\\n" \
"under the leadership of the\\n" \
"mysterious Count Dooku, has\\n" \
"made it difficult for the limited\\n" \
"number of Jedi Knights to\\n" \
"maintain peace and order in the\\n" \
"galaxy.\\n" \
"\\n" \
"Senator Amidala, the former\\n" \
"Queen of Naboo, is returning\\n" \
"to the Galactic Senate to vote\\n" \
"on the critical issue of creating\\n" \
"an ARMY OF THE REPUBLIC\\n" \
"to assist the overwhelmed\\n" \
"Jedi....\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"Episode III\\n" \
"\\n" \
"REVENGE OF THE SITH\\n" \
"\\n" \
"War!  The Republic is crumbling\\n" \
"under attacks by the ruthless\\n" \
"Sith Lord, Count Dooku.\\n" \
"There are heroes on both sides.\\n" \
"Evil is everywhere.\\n" \
"\\n" \
"In a stunning move, the\\n" \
"fiendish droid leader, General\\n" \
"Grievous, has swept into the\\n" \
"Republic capital and kidnapped\\n" \
"Chancellor Palpatine, leader of\\n" \
"the Galactic Senate.\\n" \
"\\n" \
"As the Separatist Droid Army\\n" \
"attempts to flee th besieged\\n" \
"capital with their valuable\\n" \
"hostage, two Jedi Knights lead a\\n" \
"desperate mission to rescue the\\n" \
"captive Chancellor....\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n" \
"\\n"
