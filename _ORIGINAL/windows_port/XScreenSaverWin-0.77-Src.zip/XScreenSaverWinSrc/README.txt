This is XScreenSaver for Windows (XScreenSaverWin).

This software was based on XScreenSaver 5.22 (for non-Windows OS) by 
Jamie Zawinski.

Porting to Windows was mostly done by Katayama Hirofumi MZ.

You can download binary in the XScreenSaverWin homepage.

Check STATUS.txt for porting status.
Check LICENSE.txt for licensing information.

NOTE: If you want to build the Extrusion screen saver, then 
      check the gle-3.1.0 folder.

Supported Platforms: Windows 2000/XP/Vista/Server 2003/7

-------------------------------------------------------------------------------
The XScreenSaverWin homepage
http://katahiromz.web.fc2.com/xscreensaverwin/eindex.html

XScreenSaver (original; for non-Windows)
http://www.jwz.org/xscreensaver/

GitHub XScreenSaverWin repository
https://github.com/katahiromz/XScreenSaverWin

Katayama Hirofumi MZ (Japanese)
katayama.hirofumi.mz@gmail.com
-------------------------------------------------------------------------------

/////////////////////////////////////////////////////
// Katayama Hirofumi MZ (katahiromz) [ARMYANT]
// Homepage     http://katahiromz.web.fc2.com/eindex.html
// BBS          http://katahiromz.bbs.fc2.com/
// E-Mail       katayama.hirofumi.mz@gmail.com
/////////////////////////////////////////////////////
