
//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by debughelper.rc
//

#define IDS_APP_TITLE           103

#define IDR_MAINFRAME           128
#define IDD_DEBUGHELPER_DIALOG  102
#define IDD_ABOUTBOX            103
#define IDM_ABOUT               104
#define IDM_EXIT                105
#define IDM_COPY                106
#define IDI_DEBUGHELPER         107
#define IDI_SMALL               108
#define IDC_DEBUGHELPER         109
#define IDM_200X150             110
#define IDM_320X240             111
#define IDM_640X480             112
#define IDC_MYICON              2
#ifndef IDC_STATIC
#define IDC_STATIC              -1
#endif

#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS

#define _APS_NO_MFC                 130
#define _APS_NEXT_RESOURCE_VALUE    129
#define _APS_NEXT_COMMAND_VALUE     32771
#define _APS_NEXT_CONTROL_VALUE     1000
#define _APS_NEXT_SYMED_VALUE       113
#endif
#endif
